import 'package:flutter/material.dart';

void showRequestBookDialog(BuildContext context) {
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return AlertDialog(
        title: const Text('Request New Book'),
        content: SingleChildScrollView(
          child: ListBody(
            children: <Widget>[
              TextFormField(decoration: const InputDecoration(hintText: 'Title')),
              TextFormField(decoration: const InputDecoration(hintText: 'Author')),
              TextFormField(decoration: const InputDecoration(hintText: 'Description')),
            ],
          ),
        ),
        actions: <Widget>[
          TextButton(
            child: const Text('Submit'),
            onPressed: () {
              // Handle the form submission
              Navigator.of(context).pop();
            },
          ),
        ],
      );
    },
  );
}
